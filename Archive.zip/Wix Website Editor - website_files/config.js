
window[window["TiktokAnalyticsObject"]].instance("C3SI0CO4C3S2QIOV7NI0").setAdvancedMatchingAvailableProperties({"email":true,"phone_number":true,"auto_email":false,"auto_phone_number":false});
window[window["TiktokAnalyticsObject"]].instance("C3SI0CO4C3S2QIOV7NI0").setPixelInfo && window[window["TiktokAnalyticsObject"]].instance("C3SI0CO4C3S2QIOV7NI0").setPixelInfo({status: 0, name: "base code", advertiserID: "6983679034991312898", setupMode: 1, partner: "", is_onsite: false });
window[window["TiktokAnalyticsObject"]].setPCMDomain && window[window["TiktokAnalyticsObject"]].setPCMDomain("wix.com");
window[window["TiktokAnalyticsObject"]].setPCMConfig && window[window["TiktokAnalyticsObject"]].setPCMConfig([]);
window[window["TiktokAnalyticsObject"]].enableFirstPartyCookie && window[window["TiktokAnalyticsObject"]].enableFirstPartyCookie(true);
